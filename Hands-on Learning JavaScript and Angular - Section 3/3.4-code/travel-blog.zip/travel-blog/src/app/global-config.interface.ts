// simple interface to encapsulate App config.

export interface GlobalConfig {
    
    // sample const property i want to consume.
    APP_TITLE: string;

}