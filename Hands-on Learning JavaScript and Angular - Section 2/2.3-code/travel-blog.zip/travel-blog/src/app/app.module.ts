import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { IndexListComponent } from './index-list/index-list.component';
import { CountrySelectedComponent } from './country-selected/country-selected.component';


@NgModule({
  declarations: [
    AppComponent,
    IndexListComponent,
    CountrySelectedComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
