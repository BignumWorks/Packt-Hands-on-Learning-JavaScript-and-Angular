export class Destination {
    id: number;
    name: string;
    desc: string;
}